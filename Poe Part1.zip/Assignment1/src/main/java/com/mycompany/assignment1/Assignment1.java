/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.assignment1;

import java.util.Scanner;//importing scanner

/**
 *
 * @author RC_Student_lab
 */
public class Assignment1 {

    public static void main(String[] args) {
    
    //creating a scanner class
    Scanner input =new Scanner(System.in);
     
    System.out.println("please enter your first name");
    String firstname = input.nextLine();
    
    System.out.println("please enter your last name");
    String Lastname = input.nextLine();
    
      Login objLogin = new Login();     
      
      //prompting the username
      System.out.println("Please enter your username");
      
      //user enters the username
      String username = input.nextLine();
      
      //using if statment to check the username
      if(objLogin.checkusername(username) == true){
          //Displaying the results
         System.out.println("Thank you for the username");
      }else{
          //Displaying the results
          System.out.println("The username is incorrectly formatted");

        
        
          System.out.println("please enter your password");
         String PassWord = input.nextLine();
         
        if(PassWord.length()>=8 &&
           PassWord.matches(".*[0-9].*")&&
           PassWord.matches(".*[a-z].*") &&
           PassWord.matches(".*[!@#$%^*()_+{}|:<>?].*")&&
           PassWord.matches(".*[A-Z].*")){
            
                System.out.println("Password Succesfully captured");
        }   else{
           
               
                
          System.out.println("Password is not correctly formatted; please ensure that the password the passwordd contains, a capital letter, a number, and a special character.");
     
         }
      }
      
    }
  
    
}
