   /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment1;

/**
 *
 * @author RC_Student_lab
 */
class Login {
    
    public boolean checkusername(String username){
       
        if(username.contains("_") && username.length() <= 5){
            return true;
        }
        
        else{
            return false;
        }
    }   
                   
           
    
    }
        
